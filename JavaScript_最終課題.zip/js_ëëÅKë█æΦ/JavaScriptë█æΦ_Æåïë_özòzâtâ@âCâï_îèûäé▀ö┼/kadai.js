//このファイルだけを編集し。課題を完成させる。
//このファイルは自由に編集してよい。

//ロードイベントで、初期処理を行う。
window.onload = function(){
    //課題２
    let kadai2button = document.getElementById('kadai2button');
    kadai2button.onclick = function(){
		//ここに処理を記載する
    }

    //課題３
    let kadai3 = document.getElementById('kadai3div');
    //マウスカーソルが乗ったときの処理を作成
    kadai3.onmouseenter = function(event){
		//ここに処理を記載する
    }
    //マウスカーソルが離れた時の処理を作成
    kadai3.onmouseleave = function(event){
		//ここに処理を記載する
    }

    //課題４
    let kadai4input = document.getElementById('kadai4input');
    kadai4input.oninput = function(event){
        let kadai4tbody = document.getElementById('kadai4tbody');
        //子要素の数（length）分ループする
        for(let i = 0;i < kadai4tbody.children.length; i++){
            //子要素はtbodyなので、tr、tdと掘り下げてから、tdのinnerTextを判定する
            //indexOfは、その文字を含む場合は何文字目に出現するかを返す。
            //含まない場合は-1を返すため、-1でない場合は「文字を含んでいる」と判断できる。

			//ここに処理を記載する
        }
    }

    //課題５
    let kadai5button = document.getElementById('kadai5button');
    kadai5button.onclick = function(){
		//ここに処理を記載する
        //現在の色を取得する
        //赤の場合は青にする
		//青の場合は緑にする
		//赤でも青でもない場合（緑の場合）は赤にする
    }
}

//課題1のクリックイベント
function kadai01click(){
	//ここに処理を記載する
}
