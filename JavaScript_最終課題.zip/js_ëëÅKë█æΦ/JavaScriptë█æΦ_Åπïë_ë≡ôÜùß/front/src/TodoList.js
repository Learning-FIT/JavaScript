import React from "react";

export default class TodoList extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            todos:[

            ],
            title:''
        }
    }

    componentDidMount(){
        fetch("/todos")
        .then(res => res.json())
        .then(json => {
            console.log(json);
            this.setState({
                todos:json
            })
        })
    }

    onInput = (e) => {
        const name = e.target.name;
        this.setState({
            [name]: e.target.value
        });
    }

    addTodo = () => {
        const { title } = this.state;
        const data = {title:title,status:0};
        this.setState({title:''});
        fetch("/todos/add",{
            method:"POST",
            headers: {
                "Content-Type": "application/json"
            },
            body:JSON.stringify(data)
        }).then(json =>{
            this.componentDidMount();
        });
    }

    completeTodo = (index) => {
        const {todos} = this.state; 
        const data = {id:todos[index].id,status:1};
        fetch("/todos/mod",{
            method:"POST",
            headers: {
                "Content-Type": "application/json"
            },
            body:JSON.stringify(data)
        }).then(json =>{
            this.componentDidMount();
        });
    }

    render(){
        const {title,todos} = this.state;
        return <div>
            Todoを追加<br />
            <input type="text" name="title" onChange={this.onInput} value={title}></input><br />
            <button onClick={this.addTodo}>追加</button>
            <table border="1">
                <thead>
                    <tr>
                        <th>状態</th>
                        <th>やること</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    {todos.map((todo,index) =>
                        <tr>
                            <td>{todo.status ? <span>完了</span> : <span>未完了</span>}</td>
                            <td>{todo.title}</td>
                            <td>
                                <button onClick={() =>{this.completeTodo(index)}}>完了にする</button>
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    }
}