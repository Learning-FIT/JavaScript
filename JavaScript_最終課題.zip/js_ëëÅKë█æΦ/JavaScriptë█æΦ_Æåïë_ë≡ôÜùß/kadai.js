//ロードイベントで、初期処理を行う。
window.onload = function(){
    //課題２
    let kadai2button = document.getElementById('kadai2button');
    kadai2button.onclick = function(){
        let kadai2select = document.getElementById('kadai2select');
        let kadai2option = document.createElement('option');
        kadai2option.innerText = "りんご";
        kadai2select.appendChild(kadai2option);
    }

    //課題３
    let kadai3 = document.getElementById('kadai3div');
    //マウスカーソルが乗ったときの処理を作成
    kadai3.onmouseenter = function(event){
        event.target.innerText = "選択中！";
    }
    //マウスカーソルが離れた時の処理を作成
    kadai3.onmouseleave = function(event){
        //空白を入れて高さを保っている。
        event.target.innerHTML = "&nbsp;";
    }

    //課題４
    let kadai4input = document.getElementById('kadai4input');
    kadai4input.oninput = function(event){
        let kadai4tbody = document.getElementById('kadai4tbody');
        //子要素の数（length）分ループする
        for(let i = 0;i < kadai4tbody.children.length; i++){
            //子要素はtrなので、tdまで掘り下げてからinnerTextを判定する
            //indexOfは、その文字を含む場合は何文字目に出現するかを返す。
            //含まない場合は-1を返すため、-1でない場合は「文字を含んでいる」と判断できる。
            console.log(kadai4tbody.children[i].children[0].innerText);

            if(kadai4tbody.children[i].children[0].innerText.indexOf(kadai4input.value) != -1){
                //
                kadai4tbody.children[i].style.display = "table-row";
            }else{
                kadai4tbody.children[i].style.display = "none";
            }
        }
        event.target.value;
    }

    //課題５
    let kadai5button = document.getElementById('kadai5button');
    kadai5button.onclick = function(){
        //現在の色を取得
        let kadai5div = document.getElementById('kadai5div');
        let classes = kadai5div.classList;
        if(classes.contains('red')){
            //赤なので青にする
            kadai5div.className = "blue";
        }else if(classes.contains('blue')){
            //青なので緑にする
            kadai5div.className = "green";
        }else{
            kadai5div.className = "red";
        }
    }
}

//課題1のクリックイベント
function kadai01click(){
    let div = document.getElementById('kadai1div');
    div.innerText = "ボタンが押されました。";
}
